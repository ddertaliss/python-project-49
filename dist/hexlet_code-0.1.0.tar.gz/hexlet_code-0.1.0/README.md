### Hexlet tests and linter status:
[![Actions Status](https://github.com;/fawarris/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/fawarris/python-project-49/actions
[![Maintainability](https://api.codeclimate.com/v1/badges/b5b63c9798ada845eb61/maintainability)](https://codeclimate.com/github/fawarris/python-project-49/maintainability))
