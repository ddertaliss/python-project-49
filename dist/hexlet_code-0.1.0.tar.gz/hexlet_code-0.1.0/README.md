### Hexlet tests and linter status:
[![Actions Status](https://github.com;/fawarris/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/fawarris/python-project-49/actions
[![Maintainability](https://api.codeclimate.com/v1/badges/b5b63c9798ada845eb61/maintainability)](https://codeclimate.com/github/fawarris/python-project-49/maintainability))
brain-even:
<a href="https://asciinema.org/a/eN1LyLPM2dtYx2kwUuJElqh7k" target="_blank"><img src="https://asciinema.org/a/eN1LyLPM2dtYx2kwUuJElqh7k.svg" /></a>
brain-calc:
<a href="https://asciinema.org/a/AMwQyr491AQlpRAUQY4k7IiZB" target="_blank"><img src="https://asciinema.org/a/AMwQyr491AQlpRAUQY4k7IiZB.svg" /></a>
brain-gcd:
<a href="https://asciinema.org/a/8mkTuZa1ALYsKEKPk6SzffiyZ" target="_blank"><img src="https://asciinema.org/a/8mkTuZa1ALYsKEKPk6SzffiyZ.svg" /></a>
brain-progression:
<a href="https://asciinema.org/a/yQduI0r3HE8vw2AXzc9GIndCg" target="_blank"><img src="https://asciinema.org/a/yQduI0r3HE8vw2AXzc9GIndCg.svg" /></a>
brain-prime:
<a href="https://asciinema.org/a/R2saangZprYpTSDmHGADEhTDX" target="_blank"><img src="https://asciinema.org/a/R2saangZprYpTSDmHGADEhTDX.svg" /></a>
